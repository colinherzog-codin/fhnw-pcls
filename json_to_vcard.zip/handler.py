import boto3
import json
import os

import boto3
import json

# Initialize DynamoDB and S3 clients
dynamodb = boto3.client('dynamodb')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        if record['eventName'] in ['INSERT', 'MODIFY']:
            process_insert_modify(record)
        elif record['eventName'] == 'REMOVE':
            process_remove(record)

def process_insert_modify(record):
    # Extract new data from the record
    new_data = record['dynamodb']['NewImage']
    # Implement your logic to create or update the vCard
    # Example: create_vcard(new_data)
    create_or_update_vcard(new_data)

def process_remove(record):
    # Extract old data from the record
    old_data = record['dynamodb']['OldImage']
    # Implement your logic to delete the vCard
    # Example: delete_vcard(old_data)
    delete_vcard(old_data)

def create_or_update_vcard(data):
    vcard_content = generate_vcard_content(data)
    # Save or update vCard in S3
    vcard_bucket = os.environ['S3_BUCKET_NAME']
    s3.put_object(Bucket=vcard_bucket, Key=f"{data['id']['S']}.vcf", Body=vcard_content)

def delete_vcard(data):
    # Delete vCard from S3
    vcard_bucket = os.environ['S3_BUCKET_NAME']
    s3.delete_object(Bucket=vcard_bucket, Key=f"{data['id']['S']}.vcf")
def generate_vcard_content(data):
    data = json.loads(data['body'])

    # Create a vCard string
    vcard = "BEGIN:VCARD\nVERSION:3.0\n"
    vcard += f"N:{data.get('FamilyName', '')};{data.get('GivenName', '')};;;\n"
    vcard += f"FN:{data.get('GivenName', '')} {data.get('FamilyName', '')}\n"
    vcard += f"ORG:{data.get('Company', '')}\n"
    vcard += f"TEL:{data.get('Phone', '')}\n"
    vcard += f"EMAIL:{data.get('E-Mail', '')}\n"
    vcard += f"ADR:;;{data.get('Street', '')} {data.get('Street Number', '')};{data.get('City', '')};;{data.get('Country Code', '')};{data.get('Country', '')}\n"
    vcard += "END:VCARD"
    return vcard
