import boto3
import json
import os
from vobject import vCard

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')
    bucket_name = os.environ.get('S3_BUCKET_NAME')

    # Parse JSON data
    data = json.loads(event['body'])

    # Create a vCard
    vcard = vCard()
    vcard.add('n').value = data.get('Name', '')
    vcard.add('fn').value = data.get('Name', '')
    vcard.add('org').value = data.get('Company', '')
    vcard.add('tel').value = data.get('Phone', '')
    vcard.add('email').value = data.get('E-Mail', '')
    vcard.add('adr').value = {"street": data.get('Street', '') + ' ' + data.get('Street Number', ''),
                              "city": data.get('City', ''),
                              "region": "",
                              "code": data.get('Country Code', ''),
                              "country": data.get('Country', '')}

    # Convert to vCard string
    vcard_string = vcard.serialize()

    # Generate a unique file name for the vCard file
    vcard_file_name = 'contact.vcf'  # Modify as needed for unique naming

    # Save vCard to S3 Bucket
    s3.put_object(Body=vcard_string, Bucket=bucket_name, Key=vcard_file_name,
                  ContentType='text/vcard', ACL='public-read')

    # Construct the URL to the uploaded vCard
    vcard_url = f'https://{bucket_name}.s3.amazonaws.com/{vcard_file_name}'

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'vCard created successfully', 'url': vcard_url})
    }
